When you are prompted to enter either 1 for a preset of primes, or any other number to specify your own file path...

for 1 to work, the entire program needs to be extracted elsewhere and ran through the program itself.

Or you can enter the file path of the primes.txt located in the "RSA Crypto System with Big Integer Lib" folder, or even
move the primes.txt to another place on your computer (desktop), and enter the path there (less typing).
For example it would look something like this --> Enter file path: C:\\Users\\Anthony\\Desktop\\primes.txt

This will work by just running the executable and not to have to extract the project.

I have tested this for both cases and know it works. Please let me know if you have any issues.


COMPILED AND CODED IN VISUAL STUDIO 2008 C++